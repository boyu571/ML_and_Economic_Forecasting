#############################
# Shrinkage methods and PCA #
#############################
# Dataset
install.packages('ISLR')
library(ISLR)

Hitters = na.omit(Hitters)
# ����ġ(missing value)�� �ִ� ������ ����

dim(Hitters)

n = nrow(Hitters)


# train data set�� test data set���� ����
?sample
set.seed(100)
index = sample(1:n, 163, replace=F)
train = Hitters[index,]
test = Hitters[-index,]

?model.matrix

# train data set�� X�� Y ���� 
tr.x = model.matrix(Salary~.,data=train)[,-1]
# Salary�� ������ ������ �������� X�� ����
# ù��° column�� intercept�� �ش��ϴ� 1�� �����ϰ� X�� ����
tr.x[1:5,]
tr.y = train$Salary
# Salary�� ���Ӻ����� ���� 

# test data set�� X�� Y ���� 
te.x = model.matrix(Salary~.,data=test)[,-1]
te.y = test$Salary


####################
# Ridge Regression #
####################

# For ridge and lasso, use 'glmnet' package.
install.packages('glmnet')
library(glmnet)

?glmnet
# if alpha=0 -> ridge; if alpha=1 -> lasso.
# if 0<alpha<1 -> elastic net
# Default: standardize = TRUE 

# Example
ridge=glmnet(tr.x,tr.y,alpha=0,lambda=1000)
coef(ridge)
te.yhat = predict(ridge,newx=te.x)
testmse = mean((te.y - te.yhat)^2)
testmse

# Find a tuning parameter lambda.
grid = c(10^seq(10,0,length=100),0)
ridge = glmnet(tr.x,tr.y,alpha=0,lambda=grid)
coef.ridge = coef(ridge)

te.yhat = predict(ridge,s=grid,newx=te.x)

te.mse = function (yhat,y) mean((y - yhat)^2)

mse = apply(te.yhat, 2, te.mse, y=te.y)

plot(1:101,mse,type='l',col='red',lwd=2,xlab='Index of lambda',ylab='Test MSE')

l = which(mse == min(mse))
ridge$lambda[l]
coef.ridge[,l]


####################
# Lasso Regression #
####################

grid = c(10^seq(3,0,length=50),0)

lasso = glmnet(tr.x, tr.y,alpha=1,lambda=grid)
coef.lasso = coef(lasso)
te.yhat = predict(lasso,s=grid,newx=te.x)

mse = apply(te.yhat, 2, te.mse, y=te.y)

plot(1:51,mse,type='l',col='red',lwd=2,xlab='Index of lambda',ylab='Test MSE')

l = which(mse == min(mse))
lasso$lambda[l]

coef.lasso[,l]

round(coef.lasso[,l],4)


# cv: cross validation
# cv.glmnet ------------------------------

x = model.matrix(Salary~.,data=Hitters)[,-1]
y = Hitters$Salary

# Lasso example
cvfit = cv.glmnet(x,y,family='gaussian',alpha=1)
plot(cvfit)

# lambda that gives the smallest CV stat.
cvfit$lambda.min

coef(cvfit)

yhat = predict(cvfit,newx=x,s='lambda.min')


###################################
# Principal Components Regression #
###################################

install.packages('pls')
library(pls)

set.seed(1)
?pcr
pcr.fit = pcr(Salary~., data=Hitters, scale=T, validation='CV')
# scale=T: standardize
validationplot(pcr.fit,val.type="MSEP")

opt = which.min(pcr.fit$validation$PRESS)

pcr.fit1 = pcr(Salary~., data=train, scale=T, ncomp=opt)

# New observation
new.player = list(AtBat=410, Hits=125, HmRun=5, Runs=42, RBI=57, Walks=37,
                  Years=7, CAtBat=3442, CHits=735, CHmRun=62, 
                  CRuns=300, CRBI=402, CWalks=356, 
                  League=factor('A',levels=c('A','N')),
                  Division=factor('E',levels=c('E','W')), PutOuts=582, 
                  Assists=35, Errors=9, 
                  NewLeague=factor('A',levels=c('A','N')))


yhat.new = predict(pcr.fit1, newdata = new.player)

yhat.new[,,opt]

