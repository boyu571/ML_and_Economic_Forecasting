
### Unit Root Test ###

# ADF, PP and KPSS Tests using "urca" package

getwd()
setwd("D:/2Teaching/00ForecastingMachineLearning/2023/main")
dir()

install.packages("urca")
install.packages("readxl")
library(urca)
library(readxl)

data = read.csv("2016-01.csv",header=T)

data1 = data[-1,]

attach(data1)


# Find tcode of each variable: 1) plot, 2) unit root tests


# Industrial Production Index
y1 = INDPRO
y1 = na.omit(y1) # if necessary

plot(y1, type = 'l')


# Unemployment Rate
y2 = UNRATE
plot(y2, type = 'l')

# CPI: All Items
y3 = CPIAUCSL
plot(y3, type = 'l')

y = y3

ar1=arima(y, order=c(1,0,0))
ar1

ar2=arima(y, order=c(1,0,0), xreg = 1:length(y))
ar2

y = diff(log(y))
plot(y, type = 'l')

ar1=arima(y, order=c(1,0,0))
ar1

ar2=arima(y, order=c(1,0,0), xreg = 1:length(y))
ar2

adf1=ur.df(y, type="drift")
summary(adf1)

kpss1=ur.kpss(y, type="mu", lags = "long")
kpss1
summary(kpss1)


# Housing Starts: Total New Privately Owned
y4 = HOUST
plot(y4, type = 'l')

# 10-year Treasury C Minus FEDFUNDS
y5 = T10YFFM
plot(y5, type = 'l')
