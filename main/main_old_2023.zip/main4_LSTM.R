
setwd("D:/2Teaching/BOK/ML2022/Rcodes/main")    


# LSTM Function  

# ==================================================================
# Install packages and Recall Library

#install.packages("tidyverse")
library(tidyverse)
library(ggplot2)
#library(reshape2)

install.packages("tensorflow")  #������ �������� ���� 
library(tensorflow)
install_tensorflow()

#reticulate::py_discover_config()

install.packages("keras")  #������ �������� ����
library(keras) 
install_keras()

tf$constant("hello")
tf$version

# use_condaenv("r-tensorflow") if error loading tensorflow


# ==================================================================
# Normalization

normalize <- function(x) {
  return((x-min(x))/(max(x)-min(x)))
}

# Inverse Normalization 
denormalize <- function(x, minval, maxval) {
  x*(maxval-minval) + minval
}

# ==================================================================
# Load Data Set

getwd()
dir()

load("rawdata.rda")

Y=dados

# ==================================================================
# US inflation forecasting example explanation

nprev=132
indice = 1
lag = 1

# FINAL CHECK COMPLETE

# ==================================================================
# ==================================================================
# ==================================================================
# Multivariate LSTM Model 

run_multi_lstm=function(Y,indice,lag){
  
  comp=princomp(scale(Y,scale=FALSE))
  Y2 = cbind(Y, comp$scores[,1:4]) %>% as.data.frame()
  Y3 = lapply(Y2, normalize) %>% as.data.frame() %>% as.matrix()
  aux=embed(Y3,4+lag)
  y=aux[,indice]
  X=aux[,-c(1:(ncol(Y3)*lag))]  

  if(lag==1){
    X.out=tail(aux,1)[1:ncol(X)]  
  }else{
    X.out=aux[,-c(1:(ncol(Y3)*(lag-1)))]
    X.out=tail(X.out,1)[1:ncol(X)]
  }
  
  ###
  X2 <- X %>% replace(!0, 0) 
  
  for(i in 0:(ncol(Y3)-1)){
    X2[,(4*i+1)] <- X[,(i+1)]
    X2[,(4*i+2)] <- X[,(i+ncol(Y3)+1)]
    X2[,(4*i+3)] <- X[,(i+2*ncol(Y3)+1)]
    X2[,(4*i+4)] <- X[,(i+3*ncol(Y3)+1)]
  }
  
  X.out2 <- X.out %>% replace(!0, 0)
  
  for(i in 0:(ncol(Y3)-1)){
    X.out2[(4*i+1)] <- X.out[(i+1)]
    X.out2[(4*i+2)] <- X.out[(i+ncol(Y3)+1)]
    X.out2[(4*i+3)] <- X.out[(i+2*ncol(Y3)+1)]
    X.out2[(4*i+4)] <- X.out[(i+3*ncol(Y3)+1)]
  }
  
  ###  
  X.arr = array(
    data = as.numeric(unlist(X2)),
    dim = c(nrow(X), 4, ncol(Y3)))
  
  X.out.arr = array(
    data = as.numeric(unlist(X.out2)),
    dim = c(1, 4, ncol(Y3)))
  
  # =============================================================
  set.seed(42)
  set_random_seed(42)  #tensorflow�� ��� tensorflow::set_random_seed()  �Լ��� ����ؼ� �õ� ����
  
  # Hyper-Parameters Adjustment
  
  batch_size = 25  # 25 �Ǵ� 32 �� ���� �Է��ϴ� ������ ũ�� 
  feature = ncol(Y3)  # �������� �� 
  epochs = 100  # �н� Ƚ��, 100
  
  model = keras_model_sequential()
  
  # 1-layer model ����
  
  model %>% layer_lstm(units = 32, 
                       input_shape = c(4, feature),
                       stateful = FALSE) %>%
    layer_dense(units = 1) 
  
  
  # 2-layer model with drop out (rate = 0.3)  �Ʒ� �κ� ���� 
  
  # model %>% layer_lstm(units = 32,
  #                      input_shape = c(4, feature),
  #                      stateful = FALSE,
  #                      return_sequences = TRUE) %>% 
  #   layer_dropout(rate = 0.3) %>% 
  #   layer_lstm(units = 16) %>% 
  #   layer_dropout(rate = 0.3) %>% 
  #   layer_dense(units = 1)
  
  model %>% compile(loss = 'mse', optimizer = 'adam')
  
  model %>% summary()
  
  history = model %>% fit(X.arr, y, epochs = epochs,
                          batch_size = batch_size, shuffle = FALSE, verbose = 2)
  
  # =============================================================
  
  pred = model(X.out.arr) %>% denormalize(min(Y2[,indice]),max(Y2[,indice])) # De-normalization
  
  return(list("model"=model,"pred"=pred))
}


# ============================================================================
# Multivariate Rolling 1 Step ahead LSTM Forecast

mul.lstm.rolling.window=function(Y,nprev,indice=1,lag=1){
  
  save.pred=matrix(NA,nprev,1)
  
  for(i in nprev:1){
    Y.window=Y[(1+nprev-i):(nrow(Y)-i),] %>% as.data.frame()
    lstm=run_multi_lstm(Y.window,indice,lag)
    save.pred[(1+nprev-i),]=as.numeric(lstm$pred) # Note as.numeric()
    cat("iteration",(1+nprev-i),"\n")
  }
  
  real=Y[,indice]
  plot(real,type="l")
  lines(c(rep(NA,length(real)-nprev),save.pred),col="red")
  
  rmse=sqrt(mean((tail(real,nprev)-save.pred)^2))
  mae=mean(abs(tail(real,nprev)-save.pred))
  errors=c("rmse"=rmse,"mae"=mae)
  
  return(list("pred"=save.pred,"errors"=errors))
}


multi_lstm_rolling_ex <- mul.lstm.rolling.window(Y,nprev,1,1)  
multi_lstm_rolling_ex$errors 
multi_lstm_rolling_ex$pred 

save.image("results_LSTM.RData")

load("results_LSTM.RData")

# ============================================================================
# Graphing Test Sets

date_test = seq(as.Date("1990-01-01"),as.Date("2000-12-01"), "months")

real_value = Y[,indice] %>% tail(nprev)

pred_value = multi_lstm_rolling_ex$pred

eval = data.frame(date_test, real_value, pred_value) %>% 
  set_names(c("Date","Actual","Predicted")) %>% 
  reshape2::melt(id="Date")

ggplot(data = eval, aes(x=Date, y=value, colour=variable, group=variable)) +
  geom_line(size=0.5) +
  xlab("") + ylab("") + labs(color = "") +
  scale_x_date(date_breaks ="2 year", date_labels = "%Y-%m") + 
  ggtitle("Multivariate LSTM : Actual vs Predicted") 
